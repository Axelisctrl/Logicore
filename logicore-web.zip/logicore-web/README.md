# LOGICORE

**Converse naturally. Verify intelligently.**

A self-hosted web app that combines a normal AI chat with an on-demand logical verification engine.
Chat as usual, then press **Verify Answer** (or type "verify this answer") to get a structured report:
premises, conclusions, logical reconstruction, validity, fallacies, evidence assessment, corrected answer and a final verdict.
You can also paste an answer from ChatGPT, DeepSeek, Claude or Gemini and have LOGICORE check it independently.

## Features
- Two separate modes with dedicated prompts: normal conversation (default) and 10-stage verification (only on request)
- Four verdicts: Correct, Partially Correct, Incorrect, Inconclusive
- Verify another AI's answer, with its main claims extracted and checked
- Preliminary automated checks (arithmetic, absolute wording) clearly separated from the AI verification
- Honest evidence stage: the report states that no external fact-check was done
- API keys stay on the server. Rate limiting, input validation and optional access code included
- Zero dependencies. Works with Anthropic, OpenAI and OpenAI-compatible APIs such as DeepSeek
- Responsive layout with light and dark mode

## Quick start
Requires Node.js 18 or newer.

```bash
cp .env.example .env     # then edit .env and add your API key
npm start                # open http://localhost:3000
```

Docker:

```bash
docker build -t logicore .
docker run -p 3000:3000 --env-file .env logicore
```

## Configuration (.env)
| Variable | Purpose |
|---|---|
| `PROVIDER` | `anthropic` (default) or `openai` (also DeepSeek and other compatible APIs) |
| `ANTHROPIC_API_KEY` / `OPENAI_API_KEY` | Key for the chosen provider |
| `OPENAI_BASE_URL` | Only for compatible APIs, e.g. `https://api.deepseek.com/v1` |
| `MODEL` | Model name (defaults: `claude-sonnet-5-5`, `gpt-4o`) |
| `ACCESS_CODE` | Optional. Visitors must enter this code to use the app |
| `RATE_LIMIT_PER_MIN` | Requests per IP per minute (default 30) |
| `TRUST_PROXY` | Set to `1` behind a reverse proxy so rate limiting sees real IPs |
| `PORT` | Default 3000 |

## Deploying
Any host that runs Node or Docker works (Render, Railway, Fly.io, a VPS). Set the variables above in the host's
environment settings, set `TRUST_PROXY=1`, and serve it over HTTPS. Set `ACCESS_CODE` if the site is public, because every
message uses your provider credit.

## Project layout
```
server.js      HTTP server, API routes (/api/chat, /api/verify, /api/health), provider calls
prompts.js     The chat prompt and the verification engine prompt
public/        Frontend (index.html, app.js, style.css)
```

## Limitations
- Verification judges reasoning and uses the model's own knowledge. It does not browse or cite sources.
- Conversations are stored in the visitor's browser only. There are no user accounts.

## License
See LICENSE.
